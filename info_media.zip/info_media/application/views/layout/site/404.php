<section class="cs-handbook-section1">
	<div class="container">				
		<div class="error-page col-md-12 col-sm-12 col-xs-12">
			<h6>404</h6>
			<p>Oops, sorry we can’t find that page</p>
			<a href="<?php echo base_url('home'); ?>" title="Home Page">Home Page</a>
		</div>
	</div>
</section>	