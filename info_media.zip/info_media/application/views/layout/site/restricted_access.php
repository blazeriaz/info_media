<section class="cs-handbook-section1 <?php if($this->uri->segment(1) == 'cs-steps'){ ?>col-md-9 col-sm-12 col-xs-12<?php } ?>">
	<div class="container restricted-access">				
		<div class="restricted-page col-md-12 col-sm-12 col-xs-12">
			<h6>Restricted Access</h6>
			<p>Oops, sorry You Cannot Access this Page Until Purchased</p>
			<a href="<?php echo base_url(); ?>" title="Home Page">Home Page</a>
		</div>
	</div>
</section>	