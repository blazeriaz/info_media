
<?php /*** Main Content Here **/
if( $main_content ) { 
$this->load->view($main_content); 
}
/*** Main Content end here **/ ?>
				

